BELANGRIJK: Om te zorgen dat de pagina's met elkaar verbonden zijn moet je eerst de links aanpassen zodat ze het ook doen. Alleö aanpasbare links zijn aangegeven met "LOCAL PATH".
Als je dit niet verandert werken de links niet!

Dit homepage project bestaat uit:
-  5 html bestanden
-  1 style.css bestand
-  1 styles_new.scss bestand.

De pagina's zijn een crue opzet voor een website die basisinformatie geeft over haken, een manier van handwerken die lijkt op breien. 

-- Home.html geeft een overzicht van wat er op alle paginas te zien is.
-- Basics.html geeft een overzicht van alle basissteken die bij haken gebruikt worden en linkt naar een Youtube afspeellijst voor verdere instructies.
-- Conversion.html geeft een omrekentabel weer waarin de verschillende maten van haaknaalden uit verschillende landen overzichtelijk zijn zodat je kan checken welke maat je nodig hebt indien je een internationaal patroon gebruikt.
-- contact.html is een pagina waarin contactgegevens zichtbaar zijn.
-- inspo.html laat een diavoorstelling van plaatjes zien die als inspiratie gebruikt kunnen worden.

Voor verdere vragen over dit project kun je a.lagerweij@uva.nl mailen.